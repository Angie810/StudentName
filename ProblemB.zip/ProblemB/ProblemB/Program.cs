﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ProblemB
{
    public class Student
    {
        //Create a student class which has firstName and lastName as properties
       public Student() { }

        public Student(string first, string last)
        {
            FirstName = first;
            LastName = last;
        }

        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            
            string[] listOfNames;

            List<Student> listOfStudents = new List<Student>();
            
            //read the file from the file path
            listOfNames = File.ReadAllLines(@"c:\test\sample.in");

            //temp split the firstName and the lastName from each line of the file and then add to each student
            for (int i = 0; i < listOfNames.Length; i++)
            {
                string[] temp = listOfNames[i].Split(' ');
                Student student1 = new Student(temp[0], temp[1]);
                listOfStudents.Add(student1);
            }
          
            //sorting the list by the students lastname then by firstname
            List<Student> sortedList = listOfStudents.OrderBy(s => s.LastName).ThenBy(s => s.FirstName).ToList();

            for (int i = 0; i < sortedList.Count; i++)
            {
                if (sortedList[0].FirstName != sortedList[i].FirstName)
                {
                    Console.WriteLine(sortedList[i].FirstName);
                }
                else
                {
                    Console.WriteLine(sortedList[i].FirstName + ' ' + sortedList[i].LastName);
                }
            }

        }
    }
}
